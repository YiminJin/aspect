# Stampede3 · historical BP3 60° thrust

Unpack from the directory containing the ZIP into a fresh run location. The archive creates `$SCRATCH/bp3/`. The production model is defined in one standalone file, `production.prm`. The historical coordinates and initial ages are in `historical-vertices.txt`.

## Build and submit

Load the Intel compiler, Intel MPI, deal.II and other modules used for your MPI-enabled **pf-rsf Release installation**. Use the executable and headers from the coding thread's tested core (`027e09a75` or the handoff `ee6d59cb7`). The ZIP contains the benchmark extension. The core supplies the material model, contact completion, traction filtering, timestep control and slip-triggered output. The first command below assumes the ZIP is in your current directory.

```bash
unzip bp3-stampede3.zip -d "$SCRATCH"
cd "$SCRATCH/bp3/plugins"
export ASPECT_PREFIX=/absolute/path/to/your/pf-rsf-release-install
cmake -S . -B . -DAspect_DIR="$ASPECT_PREFIX/lib/cmake/Aspect"
cmake --build . -j2

cd "$SCRATCH/bp3"
./plugins/aspect-release --validate production.prm
sbatch -A YOUR_TACC_ALLOCATION submit.sh
```

If you already have the matching `Aspect_DIR`, pass `-DAspect_DIR="$Aspect_DIR"` to CMake. The ASPECT CMake package creates `plugins/aspect-release` pointing to the matching executable. After building, the launcher uses that link and `plugins/libbp3_qd.release.so` directly. No run-directory or plugin-search environment variable is needed. Keep the same module environment at submission. Python 3.7+ with the standard library, Slurm and TACC's `ibrun` suffice for the default job.

## What runs overnight

The first allocation starts the **full production mesh**, checkpoints after accepted step 1, resumes it through step 3, and continues from that checkpoint within the same allocation. Both bounded segments write every full fault profile and bulk frame. They use the production physics and select the existing time-zero transect observer. The launcher verifies the 552,084-cell mesh, accepted clocks, 5,776 IDs, peak rate and location, age and slip updates, both timestep budgets, three cut integrals, frame catalogue, declared native fields, nonempty pieces and the published terminal checkpoint. It prints rate, shear and raw/filtered compression at both contacts. The full-field numerical traction reconstruction is available separately below. A failed solver or failed startup check ends the allocation and preserves its files.

After step 3 the same job restores the sparse production cadence. Fault profiles are written at 0.1 m accumulated slip, one year or event milestones. Bulk visualization uses 1 m or 100 years. The model stops after the first peak at or above 0.001 m/s followed by five consecutive accepted peaks below that threshold, or at 1,500 Julian years. Initialization uses a 100 s Maxwell interval. The ceiling on the first physical step is 4 million s. Default linear and nonlinear tolerances are 1e-9 and 1e-8.

`submit.sh` requests two ICX nodes with 80 ranks per node and one thread per rank. Its 48-hour limit applies to one allocation. Each ASPECT invocation uses its native wall-time criterion, calculated from the remaining allocation time with a 30-minute checkpoint margin. ASPECT checks this criterion at accepted-step boundaries. Checkpoints are also scheduled every 1,800 wall seconds. Measure full-grid step and checkpoint time on the server and increase `MARGIN_SECONDS` in `tools/run.py` if necessary. The elapsed time spent in an unfinished solve or filesystem stall can exceed this margin.

## Inspect, stop or continue

```bash
cd "$SCRATCH/bp3"
squeue -u "$USER"
tail -n 40 bp3-JOBID.out
ls -lt jobs/*/*.log | head
tail historical-output/statistics
cat historical-output/startup-step-{1,3}.ok
```

Replace `JOBID` with the ID printed by Slurm. The batch output identifies the active per-segment solver log. The two `.ok` files appear as their checks pass. The Slurm output contains the startup contact values. Each directory under `jobs/` retains the effective inputs as text, the binary and input hashes, and the solver logs. The root `production.prm` is the only input to edit. Each generated input adjusts only resume, termination and startup output controls. Keep the scientific input, vertex file and installation fixed across restarts of this run.

To request an early stop while the solver is running, use `touch historical-output/terminate-aspect`. Wait for ASPECT to finish the step and checkpoint, and for the job to exit. An immediate `scancel JOBID` can lose progress since the latest completed checkpoint.

After a wall-time stop, submit the next allocation explicitly from the same directory. The native wall-time criterion leaves no stop file.

```bash
cd "$SCRATCH/bp3"
sbatch -A YOUR_TACC_ALLOCATION submit.sh resume
```

If you stopped manually, archive your `terminate-aspect` file first, e.g. `mv historical-output/terminate-aspect "historical-output/stop-$(date +%s)"`. The launcher refuses overlapping writers and a fresh launch into existing output. A resume uses the last published native checkpoint and finishes either startup check still pending. If startup failed before the first checkpoint, inspect the solver log, preserve the failed directory and use a fresh start. After the first-event or model-time criterion finishes, `historical-output/bp3-complete.txt` records the cause. The script submits no further allocations.

## Optional numerical review

The startup frame check reads the PVD/PVTU catalogues and checks the referenced files. For a numerical reconstruction of the initial FE phase, prescribed velocity and both contact tractions, plus the filter and accepted history through step 3, use a separate analysis session with adequate memory, NumPy 2+, SciPy and VTK. The full-grid analysis loads the native time-zero field and all its discontinuous patch traces. Run after the startup checkpoints have closed and the PVD is stable, or against a copy of the outputs.

```bash
OPENBLAS_NUM_THREADS=1 python3 tools/check_historical.py historical-output --through-step 3
python3 tools/history.py historical-output/statistics accepted-history
```

The second command uses only the Python standard library. It exports peak and station CSV files to a **new** directory. Use it on a stable statistics file.

## Choosing a node count

The archived donor used two nodes and 160 ranks for 552,081 cells and 5,776 fault IDs. Its warm interseismic loading averaged 63.16 s per accepted step on steps 100–700. Today's input has 552,084 cells and the same number of IDs. The donor supplies a starting layout. The new solver has no full-grid strong-scaling measurement. For a comparison, replay the same checkpoint with independent output directories and the same accepted-step window on one and two ICX nodes. Compare wall seconds and node-seconds per accepted step, excluding restart setup and matching the output cadence and nonlinear iteration counts. Increasing the node count beyond two is justified if the measured speedup is worth the extra node-hours.

[Stampede3 system specifications](https://docs.tacc.utexas.edu/hpc/3stampede/system/) · [Queue limits and job submission](https://docs.tacc.utexas.edu/hpc/3stampede/running/)
